# Terraform_S3_Automation
Terraform will create a S3 bucket. Python script will raise an alert if files are found in that S3 bucket.
